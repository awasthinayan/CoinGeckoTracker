
import axiosInstance from '../Axios_Instance/Axios_Inst'

export async function fetchCoinData(id) {
    try {
        const response = await axiosInstance.get(`/coins/${id}`);
        return response.data;

    } catch(error) {
        console.error(error);
        return null;
    }
}