
import CoinTable2 from '../Navbar2/CoinTable_axios'
import Banner from '../Components/Banner/Banner'

const Home = () => {
  return (
    <div>
        <Banner/>
        <CoinTable2/>
    </div>
  )
}

export default Home