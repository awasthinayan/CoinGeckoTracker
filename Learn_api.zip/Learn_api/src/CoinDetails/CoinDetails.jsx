import React from 'react'
import {useParams} from 'react-router-dom'
const CoinDetails = () => {
  const {coinid} = useParams();

  return (
    <div>
        <h1>Coin Details</h1>
        <p>Coin ID: {coinid}</p>
    </div>
  )
}

export default CoinDetails